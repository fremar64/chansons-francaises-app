// TypeScript config loader pour CEREDIS
import ceredisConfig from './ceredis.v1.json';

export default ceredisConfig;
