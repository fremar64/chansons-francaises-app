/**
 * Barrel export pour les composants du Dashboard
 */

export { RadarCompetences } from './RadarCompetences';
export { HistoriqueActivites } from './HistoriqueActivites';
export { ProgressionGlobale } from './ProgressionGlobale';
