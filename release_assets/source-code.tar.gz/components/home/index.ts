export { HeroSection } from './HeroSection';
export { FeaturedParcours } from './FeaturedParcours';
export { HowItWorks } from './HowItWorks';
export { UserSpaces } from './UserSpaces';
export { CompetencesSection } from './CompetencesSection';
export { AvantagesSection } from './AvantagesSection';
export { CTASection } from './CTASection';
